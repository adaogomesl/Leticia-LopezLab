from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import LightSource
from matplotlib import cm
from matplotlib.ticker import StrMethodFormatter
import matplotlib.colors as col
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
import sys,json
import matplotlib as mpl
mpl.use('Agg')

title='DBH-60:40-BoxPlot-100'
choose = 0

###COLLECT DATA###

dfe = pd.DataFrame()
# load data
with open('data.json','r') as indata: 
	data = json.load(indata)

energies = data['energy']

j = 1 
s0_E = 251.36520721

state = []
for i in energies:
	state.append(i[0])

a1 = [((i + s0_E)*27.2114) for i in state]

for i in range(0,2560,16):
	dfe['wigner_set'+str(j)] = a1[i:i+2]
	j = j + 1 	

ind = []
for i in range(2):
	ind.append(i+1)

#Format the data here 
dfe['coord'] = ind
dfe.set_index('coord',inplace = True)
dfv = dfe.transpose()
avg = dfv.mean(axis = 'index')

###GRAPH###

fig=plt.figure()
df = fig.add_subplot()
df.spines['right'].set_visible(True)
df.spines['top'].set_visible(True)
plt.subplots_adjust(wspace=0.3,hspace=0.3,bottom=0.2)
df.axes.tick_params(axis='both',direction='in')
#### Format
df.set_xlabel('Energy',fontsize=18,labelpad=8)
df.set_ylabel(r'Number of molecules',fontsize=18,labelpad=8)

#### Plot data
df.hist(dfv[2],range=None,bins=100,alpha=0.5)
fig.savefig("%s.png" % (title),bbox_inches="tight",dpi=400)

