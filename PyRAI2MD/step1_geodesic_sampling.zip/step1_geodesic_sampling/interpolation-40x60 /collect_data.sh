for((a=1;a<=60;a++)); do for((b=1;b<=40;b++));do echo $PWD/dbh-$a/dbh-$a-$b >> full_list.txt; done; done
