# set number of	geometries  
n_interp=20
n_wigner=60

# initialize empty list	files
> interp.txt
> wigner.txt

# loop over the xyz of the interpolated part 1
for ((a=1;a<=$n_interp;a++))
do
echo $PWD/first_part/dbh-$a.xyz	>> interp.txt
done

# loop over the xyz of the interpolated part 2
for ((a=1;a<=$n_interp;a++))
do
echo $PWD/second_part/dbh-$a.xyz >> interp.txt
done

# add reference structrure to wigner list file
echo $PWD/wigner/dbh-reactant.xyz >> wigner.txt

# loop over the xyz of the wigner sampled geometries
for ((a=1;a<=$n_wigner;a++))
do
echo $PWD/wigner/dbh-$a.xyz >> wigner.txt
done
