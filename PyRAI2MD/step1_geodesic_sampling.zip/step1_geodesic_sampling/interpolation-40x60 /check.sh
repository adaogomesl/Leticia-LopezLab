> check.txt
title='dbh'
for ((i = 1 ; i <= 60 ; i++)); do

        for((j = 1 ; j <=40 ; j++)); do

        log=$title-${i}/$title-${i}-${j}/$title-${i}-${j}.log
        flag=`tail $log |grep Happy`
        echo "$PWD/$title-${i}/$title-${i}-${j} $flag" >> check.txt
        done

done
