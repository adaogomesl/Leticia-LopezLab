import os,sys
import numpy as np

def batch(name,path,logpath,add):

    script="""#!/bin/sh
## script for OpenMalCas
## $INPUT and $WORKDIR do not belong to OpenMolCas
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --time=12:00:00
#SBATCH --job-name=%s
#SBATCH --partition=lopez
#SBATCH --mem=7Gb
#SBATCH --output=%%j.o.slurm
#SBATCH --error=%%j.e.slurm
#SBATCH --constraint="[broadwell|haswell|cascadelake|ib]"

if [ -d "/srv/tmp" ]
then
 export LOCAL_TMP=/srv/tmp
else
 export LOCAL_TMP=/tmp
fi

export INPUT=%s
export WORKDIR=%s

export MOLCAS_NPROCS=$SLURM_NTASKS
export MOLCAS_MEM=5000
export MOLCAS_PRINT=3
export MOLCAS_PROJECT=$INPUT
export MOLCAS_WORKDIR=$LOCAL_TMP/$USER/$SLURM_JOB_ID
export OMP_NUM_THREADS=1
export MOLCAS=/work/lopez/Molcas
export PATH=$MOLCAS/bin:$PATH

cd $WORKDIR
mkdir -p $MOLCAS_WORKDIR/$MOLCAS_PROJECT
date                 >> %s/logfile.txt
$MOLCAS/bin/pymolcas -f $INPUT.inp -b 1
rm -r $MOLCAS_WORKDIR/$MOLCAS_PROJECT
echo "$WORKDIR DONE" >> %s/logfile.txt
date                 >> %s/logfile.txt
echo ""              >> %s/logfile.txt

%s
""" % (name,name,path,logpath,logpath,logpath,logpath,add)

    return script

def readXYZ(xyz):

    with open(xyz, 'r') as input:
        coord = input.read().splitlines()

    natom = int(coord[0])
    coord = np.array([x.split() for x in coord[2: 2 + natom]])
    atom = coord[:, 0].reshape((-1,1))
    coord = coord[:, 1: 4].astype(float)

    return atom, coord

def writeXYZ(atom, xyz):

    natom = len(atom)
    coord = np.concatenate((atom, xyz), axis = 1)
    output = '%s\n\n%s' % (natom, 
        ''.join(['%-5s%24.16f%24.16f%24.16f\n' % (
            str(line[0]), float(line[1]), float(line[2]), float(line[3])) for line in coord]
            )
        )

    return output

logpath=os.getcwd()
title='%s' % sys.argv[1].split('.')[0]

with open('%s.inp' % (title), 'r') as input:
    inptemp = input.read()

with open('%s.StrOrb' % (title), 'r') as input:
    guessorb = input.read()

with open('wigner.txt', 'r') as input:
    wigner = input.read().splitlines()
    ref = wigner[0]
    wigner = wigner[1:]

with open('interp.txt', 'r') as input:
    interp = input.read().splitlines()

wigner_pool = []
interp_pool = []
runall=''

atom, ref_coord = readXYZ(ref)

for distr in wigner:
    atom, wigner_coord = readXYZ(distr)
    wigner_pool.append(wigner_coord)

for inter in interp:
    atom, interp_coord = readXYZ(inter)
    interp_pool.append(interp_coord)

for i, distr in enumerate(wigner_pool):
    dr = distr - ref_coord
    for j, inter in enumerate(interp_pool):
        crntname='%s-%d-%d' % (title, i + 1, j + 1)
        crntpath='%s/%s-%d/%s' % (logpath, title, i+1, crntname)
        new_coord = inter + dr
        new_coord = writeXYZ(atom, new_coord)

        if os.path.exists('%s' % (crntpath)) == False:
            os.makedirs('%s' % (crntpath))

        with open('%s/%s.inp'  % (crntpath, crntname), 'w') as out:
            out.write(inptemp)

        with open('%s/%s.StrOrb'  % (crntpath, crntname), 'w') as out:
            out.write(guessorb)

        with open('%s/%s.xyz'  % (crntpath, crntname), 'w') as out:
            out.write(new_coord)

        with open('%s/run_molcas.sh' % (crntpath), 'w') as out:
            out.write(batch(crntname,crntpath,logpath,''))

        runall += 'cd %s;sbatch run_molcas.sh\n' % (crntpath)

with open('%s/runall.sh' % (logpath),'w') as out:
    out.write(runall)
