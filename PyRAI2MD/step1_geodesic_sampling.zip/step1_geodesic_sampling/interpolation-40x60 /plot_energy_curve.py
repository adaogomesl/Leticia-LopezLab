from mpl_toolkits.mplot3d import Axes3D

from matplotlib.colors import LightSource
from matplotlib import cm
from matplotlib.ticker import StrMethodFormatter
import matplotlib.colors as col
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
import sys,json
import matplotlib as mpl
mpl.use('Agg')

title='geodesic_data60-40-boxplox50-S0' # title of this figure
choose = 0

dfe = pd.DataFrame()
# load data
with open('data.json','r') as indata: 
	data = json.load(indata)

energies = data['energy']

j = 1 
s0_E = 303.0015761370

state = []
for i in energies:
	state.append(i[0])

a1 = [((i + s0_E)*27.2114) for i in state]

for i in range(0,1180,40):
	dfe['wigner_set'+str(j)] = a1[i:i+40]
	j = j + 1 	

ind = []
for i in range(40):
	ind.append(i+1)


dfe['coord'] = ind
dfe.set_index('coord',inplace = True)
df = dfe.transpose()
avg = df.mean(axis = 'index')

print(dfe)
print(avg)


fig=plt.figure()
ax = fig.add_subplot()
ax.spines['right'].set_visible(True)
ax.spines['top'].set_visible(True)
#plt.subplots_adjust(wspace=0.3,hspace=0.3,bottom=0.2)
ax.axes.tick_params(axis='both',direction='in')
plt.xticks(fontsize=5, weight='bold')
plt.yticks(fontsize=15, weight='bold')
ax.set_ylabel('E (eV)',fontsize=16,labelpad=8)
sns.boxplot(data=df)
ax.set_xlabel('Interpolated Step',fontsize=16,labelpad=8)
#ax.scatter(ind, avg, color = 'black', s=2, alpha=0.3)
#ax.plot(steps, s1, color = 'orange', marker='o',markersize=0., linewidth=1.5, linestyle='-', alpha=0.3)
#ax.plot(steps, s2, color = 'red',    marker='o',markersize=0., linewidth=1.5, linestyle='-', alpha=0.3)

stats = pd.DataFrame()
stats['max_values'] = df.max(axis=0)
stats['min_values'] = df.min(axis=0)
stats['std_values'] = df.std(axis=0, ddof=1)
print(stats)
#stats.to_excel('stats.xlsx')
fig.savefig("%s.png" % (title),bbox_inches="tight",dpi=400)

