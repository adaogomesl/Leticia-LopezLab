import numpy as np
import sys

with open(sys.argv[1]) as inlist: coord_list=inlist.read().splitlines()

ref=coord_list[0]
coord_list=coord_list[1:]

def ReadXYZ(coord):
    with open(coord,'r') as inxyz: xyz=inxyz.read().splitlines()
    natom=int(xyz[0])
    xyz=xyz[2:2+natom]
    xyz=np.array([x.split() for x in xyz])
    atom=xyz[:,0]
    xyz=xyz[:,1:4].astype('float')

    return atom,xyz

def WriteXYZ(atom,coord):
    natom=len(coord)
    xyz='%s\n\n' % (natom)
    for n in range(natom):
        xyz+='%-5s%18.10f%18.10f%18.10f\n' % (atom[n],coord[n][0],coord[n][1],coord[n][2])

    return xyz

def Align(interp,xyz):
    P=interp.copy()
    Q=xyz.copy()
    Pcentroid=P.mean(axis=0)
    Qcentroid=Q.mean(axis=0)
    P-=Pcentroid
    Q-=Qcentroid
    C = np.dot(np.transpose(P), Q)
    V, S, W = np.linalg.svd(C)
    d = (np.linalg.det(V) * np.linalg.det(W)) < 0.0
    if d:                    # ensure right-hand system
        S[-1] = -S[-1]
        V[:, -1] = -V[:, -1]
    U = np.dot(V, W)

    coord=np.dot(interp-Pcentroid,U)+Qcentroid

    return coord

atom,ref=ReadXYZ(ref)
for coord in coord_list:
    name=coord.split('.xyz')[0]
    atom,coord=ReadXYZ(coord)
    coord=Align(coord,ref)
    outxyz=WriteXYZ(atom,coord)

    with open('%s-overlay.xyz' % (name),'w') as out: out.write(outxyz)
