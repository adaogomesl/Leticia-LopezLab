# this is the full path
# /work/lopez/Python-3.7.4/bin/geodesic_interpolate filename.xyz --output output.xyz --nimages 20

geodesic_interpolate $1 --output output.xyz --nimages $2
