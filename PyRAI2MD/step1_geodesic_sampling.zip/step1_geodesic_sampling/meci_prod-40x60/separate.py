import sys
title=sys.argv[2]

with open(sys.argv[1],'r') as inxyz:
    xyz=inxyz.read().splitlines()

natom=int(xyz[0])

i=0
for n,line in enumerate(xyz):
    if 'Frame' in line:
        i+=1
        coord='\n'.join(xyz[n-1:n+natom+1])+'\n'
        with open('%s-%s.xyz' % (title,i),'w') as out:
            out.write(coord)

